const version = "© FishyBots 1.8.1";

module.exports = { version };